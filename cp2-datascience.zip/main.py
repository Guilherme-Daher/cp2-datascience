import pandas as pd
import numpy as np
from jinja2 import Template
import matplotlib.pyplot as plt
import seaborn as sns
import io
import base64
from datetime import datetime

class DataProfiler:
    def __init__(self, df):
        self.df = df
        self.numeric_columns = df.select_dtypes(include=['int64', 'float64']).columns
        self.categorical_columns = df.select_dtypes(exclude=['int64', 'float64']).columns
        
    def get_basic_info(self):
        return {
            'Número de Linhas': len(self.df),
            'Número de Colunas': len(self.df.columns),
            'Uso de Memória': f"{self.df.memory_usage(deep=True).sum() / 1024**2:.2f} MB",
            'Colunas Numéricas': len(self.numeric_columns),
            'Colunas Categóricas': len(self.categorical_columns)
        }
    
    def get_column_info(self):
        column_info = {}
        for column in self.df.columns:
            info = {
                'Tipo de Dados': str(self.df[column].dtype),
                'Valores Nulos': self.df[column].isnull().sum(),
                'Porcentagem de Nulos': f"{(self.df[column].isnull().sum() / len(self.df)) * 100:.2f}%",
                'Valores Únicos': self.df[column].nunique()
            }
            
            if column in self.numeric_columns:
                info.update({
                    'Média': f"{self.df[column].mean():.2f}",
                    'Desvio Padrão': f"{self.df[column].std():.2f}",
                    'Mínimo': f"{self.df[column].min():.2f}",
                    'Máximo': f"{self.df[column].max():.2f}",
                    '25%': f"{self.df[column].quantile(0.25):.2f}",
                    'Mediana': f"{self.df[column].median():.2f}",
                    '75%': f"{self.df[column].quantile(0.75):.2f}"
                })
            
            column_info[column] = info
        return column_info

    def plot_to_base64(self, fig):
        img_data = io.BytesIO()
        fig.savefig(img_data, format='png', bbox_inches='tight')
        plt.close(fig)
        img_data.seek(0)
        return base64.b64encode(img_data.getvalue()).decode()

    def generate_correlation_plot(self):
        if len(self.numeric_columns) > 0:
            plt.figure(figsize=(12, 10))
            corr = self.df[self.numeric_columns].corr()
            sns.heatmap(corr, annot=True, cmap='coolwarm', vmin=-1, vmax=1)
            plt.title('Matriz de Correlação')
            return self.plot_to_base64(plt.gcf())
        return None

    def generate_distribution_plots(self):
        plots = {}
        for column in self.numeric_columns[:5]:
            fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8), height_ratios=[3, 1])
            
            # Histogram with KDE
            sns.histplot(data=self.df, x=column, kde=True, ax=ax1)
            ax1.set_title(f'Distribuição de {column}')
            
            # Box plot
            sns.boxplot(data=self.df, x=column, ax=ax2)
            ax2.set_title(f'Box Plot de {column}')
            
            plt.tight_layout()
            plots[column] = self.plot_to_base64(fig)
        return plots

    def generate_category_plots(self):
        plots = {}
        for column in self.categorical_columns[:5]:
            if self.df[column].nunique() <= 30:  # Limit to avoid overcrowded plots
                plt.figure(figsize=(10, 6))
                value_counts = self.df[column].value_counts().nlargest(10)
                sns.barplot(x=value_counts.index, y=value_counts.values)
                plt.xticks(rotation=45, ha='right')
                plt.title(f'Top 10 Valores em {column}')
                plots[column] = self.plot_to_base64(plt.gcf())
        return plots

    def generate_missing_data_plot(self):
        plt.figure(figsize=(10, len(self.df.columns) * 0.3))
        missing_data = (self.df.isnull().sum() / len(self.df) * 100).sort_values(ascending=True)
        sns.barplot(x=missing_data.values, y=missing_data.index)
        plt.title('Porcentagem de Dados Faltantes por Coluna')
        plt.xlabel('Porcentagem de Dados Faltantes')
        return self.plot_to_base64(plt.gcf())

    def generate_report(self):
        basic_info = self.get_basic_info()
        column_info = self.get_column_info()
        correlation_plot = self.generate_correlation_plot()
        distribution_plots = self.generate_distribution_plots()
        category_plots = self.generate_category_plots()
        missing_data_plot = self.generate_missing_data_plot()
        
        template = Template('''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Relatório de Análise de Dados</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    margin: 0;
                    padding: 20px;
                    background-color: #f5f5f5;
                }
                .container {
                    max-width: 1200px;
                    margin: 0 auto;
                    background-color: white;
                    padding: 20px;
                    border-radius: 8px;
                    box-shadow: 0 0 10px rgba(0,0,0,0.1);
                }
                h1 {
                    color: #2c3e50;
                    text-align: center;
                    padding-bottom: 10px;
                    border-bottom: 2px solid #3498db;
                }
                h2 {
                    color: #34495e;
                    margin-top: 30px;
                }
                table {
                    border-collapse: collapse;
                    width: 100%;
                    margin-bottom: 20px;
                    background-color: white;
                }
                th, td {
                    border: 1px solid #ddd;
                    padding: 12px;
                    text-align: left;
                }
                th {
                    background-color: #3498db;
                    color: white;
                }
                tr:nth-child(even) {
                    background-color: #f2f2f2;
                }
                img {
                    max-width: 100%;
                    height: auto;
                    margin-top: 10px;
                    margin-bottom: 20px;
                }
                .section {
                    margin-bottom: 40px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Relatório de Análise de Dados</h1>
                <p><strong>Gerado em:</strong> {{ datetime.now().strftime('%Y-%m-%d %H:%M:%S') }}</p>
                
                <div class="section">
                    <h2>Informações Básicas</h2>
                    <table>
                        <tr><th>Métrica</th><th>Valor</th></tr>
                        {% for key, value in basic_info.items() %}
                        <tr><td>{{ key }}</td><td>{{ value }}</td></tr>
                        {% endfor %}
                    </table>
                </div>
                
                <div class="section">
                    <h2>Dados Faltantes</h2>
                    <img src="data:image/png;base64,{{ missing_data_plot }}" alt="Dados Faltantes">
                </div>
                
                {% if correlation_plot %}
                <div class="section">
                    <h2>Matriz de Correlação</h2>
                    <img src="data:image/png;base64,{{ correlation_plot }}" alt="Matriz de Correlação">
                </div>
                {% endif %}
                
                <div class="section">
                    <h2>Análise de Variáveis Numéricas</h2>
                    {% for column, plot in distribution_plots.items() %}
                    <h3>{{ column }}</h3>
                    <img src="data:image/png;base64,{{ plot }}" alt="Distribuição de {{ column }}">
                    {% endfor %}
                </div>
                
                {% if category_plots %}
                <div class="section">
                    <h2>Análise de Variáveis Categóricas</h2>
                    {% for column, plot in category_plots.items() %}
                    <h3>{{ column }}</h3>
                    <img src="data:image/png;base64,{{ plot }}" alt="Análise de {{ column }}">
                    {% endfor %}
                </div>
                {% endif %}
                
                <div class="section">
                    <h2>Informações Detalhadas das Colunas</h2>
                    {% for column, info in column_info.items() %}
                    <h3>{{ column }}</h3>
                    <table>
                        {% for key, value in info.items() %}
                        <tr><td>{{ key }}</td><td>{{ value }}</td></tr>
                        {% endfor %}
                    </table>
                    {% endfor %}
                </div>
            </div>
        </body>
        </html>
        ''')
        
        return template.render(
            basic_info=basic_info,
            column_info=column_info,
            correlation_plot=correlation_plot,
            distribution_plots=distribution_plots,
            category_plots=category_plots,
            missing_data_plot=missing_data_plot,
            datetime=datetime
        )

def generate_profile_report(df, output_file='report.html'):
    profiler = DataProfiler(df)
    report_html = profiler.generate_report()
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(report_html)
    
    print(f"Relatório gerado com sucesso: {output_file}")

# Exemplo de uso
if __name__ == "__main__":
    try:
        # Carregando o dataset do Spotify
        df = pd.read_csv('spotify_data.csv')
        
        # Gerando o relatório
        generate_profile_report(df, 'spotify_analysis_report.html')
    except Exception as e:
        print(f"Erro ao gerar o relatório: {str(e)}")